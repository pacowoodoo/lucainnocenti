<?php

/**
 * Sitemap resource product collection model
 *
 * @category    Lucainnocenti
 * @package     Lucainnocenti_Superseositemap
 * @author      Magento Core Team <core@magentocommerce.com>
 * @editor      Luca Innocenti
 */
class Lucainnocenti_Superseositemap_Model_Resource_Catalog_Product extends Mage_Sitemap_Model_Resource_Catalog_Product {


    public function getProductImageListBySku($storeId) {
    
        $resource = Mage::getSingleton('core/resource');
        $readConnection = $resource->getConnection('core_read');
        
        $showImagesWithNoLabel = Mage::getStoreConfig('sitemap/superseositemap/' .Lucainnocenti_Superseositemap_Model_Sitemap::SHOWIMAGESWITHNOLABEL);

        $idImagesSql = "SELECT a.entity_id, b.value_id,b.value, c.label
        FROM `catalog_product_entity` AS a
        LEFT JOIN `catalog_product_entity_media_gallery` AS b ON a.entity_id = b.entity_id
        LEFT JOIN `catalog_product_entity_media_gallery_value` AS c ON b.value_id = c.value_id
        WHERE b.value IS NOT NULL AND (c.store_id = $storeId OR c.store_id = 0) ";
        if(!$showImagesWithNoLabel){
            $idImagesSql .= " AND c.label IS NOT NULL ";
        }
        $idImagesSql .= "ORDER BY store_id ASC , b.value_id ASC
        ; ";

        /**
         * Execute the query and store the results in $results
         */
        $idImagesList = $readConnection->fetchAll($idImagesSql);

        $idImagesArray = array();

        foreach ($idImagesList as $image) {
            $imageA = array();
            $imageA["image"] = $image["value"];
            $imageA["label"] = $image["label"]; 
            
            $idImagesArray[$image["entity_id"]][$image["value_id"]] = $imageA;
        }

        /**
         * Print out the results
         */
        return $idImagesArray;
    }

}
