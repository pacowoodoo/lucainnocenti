<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magentocommerce.com for more information.
 *
 * @category    Mage
 * @package     Mage_Sitemap
 * @copyright   Copyright (c) 2010 Magento Inc. (http://www.magentocommerce.com)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Sitemap resource product collection model
 *
 * @category   Mage
 * @package    Mage_Sitemap
 * @author      Magento Core Team <core@magentocommerce.com>
 */

class Lucainnocenti_Superseositemap_Model_Mysql4_Catalog_Product extends Mage_Sitemap_Model_Mysql4_Catalog_Product
{
    public function getProductImageListBySku($storeId) {
    
        $resource = Mage::getSingleton('core/resource');
        $readConnection = $resource->getConnection('core_read');
        
        $idImagesSql = "SELECT a.entity_id, b.value_id,b.value, c.label
        FROM `catalog_product_entity` AS a
        LEFT JOIN `catalog_product_entity_media_gallery` AS b ON a.entity_id = b.entity_id
        LEFT JOIN `catalog_product_entity_media_gallery_value` AS c ON b.value_id = c.value_id
        WHERE b.value IS NOT NULL AND (c.store_id = $storeId OR c.store_id = 0) AND c.label IS NOT NULL 
        ORDER BY store_id ASC , b.value_id ASC
        ; ";

        /**
         * Execute the query and store the results in $results
         */
        $idImagesList = $readConnection->fetchAll($idImagesSql);

        $idImagesArray = array();

        foreach ($idImagesList as $image) {
            $imageA = array();
            $imageA["image"] = $image["value"];
            $imageA["label"] = $image["label"]; 
            
            $idImagesArray[$image["entity_id"]][$image["value_id"]] = $imageA;
        }

        /**
         * Print out the results
         */
        return $idImagesArray;
    }
}
